package com.qipz.activityrecognition;

import android.content.Context;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class UploadManager {
    private final Context context;
    private static final long PERIODIC_INTERVAL_MINUTES = 15L;

    public UploadManager(Context context) {
        this.context = context.getApplicationContext();
    }

    public void scheduleUpload() {
        ensurePeriodicUpload();
        Constraints constraints = new Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build();

        OneTimeWorkRequest work = new OneTimeWorkRequest.Builder(LocationUploadWorker.class)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("qipz_location_upload")
            .build();

        WorkManager.getInstance(context)
            .enqueueUniqueWork("qipz_upload", ExistingWorkPolicy.KEEP, work);
    }

    public void ensurePeriodicUpload() {
        Constraints constraints = new Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build();

        PeriodicWorkRequest work = new PeriodicWorkRequest.Builder(
            LocationUploadWorker.class, PERIODIC_INTERVAL_MINUTES, TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .build();

        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork("qipz_upload_periodic", ExistingPeriodicWorkPolicy.KEEP, work);
    }
}
