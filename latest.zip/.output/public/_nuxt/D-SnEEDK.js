import{_ as e}from"./DlAUqK2U.js";import{c,o}from"./BrVZsdVc.js";const r={};function t(s,n){return o(),c("div",null,"this is projects")}const f=e(r,[["render",t]]);export{f as default};
